export interface CartProduct {
  product: {
    name: string;
    price: number;
    image: string;
  }
  quantity: number;
}