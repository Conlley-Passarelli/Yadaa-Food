export interface Product {
  id: string;
  fields: {
    Name: string;
    Amount: number;
    Image: string;
  }
}
